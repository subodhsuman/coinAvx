<template>
<div>
    <div class="chart_box d-flex justify-content-center align-items-center border">
        <h1>EXCHANGE CHART</h1>
    </div>
</div>
</template>

<script>
export default {

}
</script>

<style scoped>
.chart_box{
    min-height: 400px;
}
</style>
