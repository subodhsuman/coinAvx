<template>
<div>
    <div class="col-md-12 col-lg-12 col-xl-12">
        <div class="setting_sub_heading d-md-flex d-block justify-content-between">
            <h6 class="text-uppercase mb-5">{{sub_heading}}</h6>
            <!-- <div class="wallet_box">
                <p class="mb-0">Wallet Balance
                    <span> <svg xmlns="http://www.w3.org/2000/svg" width="15.541" height="15.757" viewBox="0 0 15.541 21.757">
                            <path id="Icon_awesome-rupee-sign" data-name="Icon awesome-rupee-sign" d="M14.958,5.358a.583.583,0,0,0,.583-.583V2.833a.583.583,0,0,0-.583-.583H.583A.583.583,0,0,0,0,2.833V5.006a.583.583,0,0,0,.583.583H4.724A3.5,3.5,0,0,1,7.686,6.912H.583A.583.583,0,0,0,0,7.5V9.438a.583.583,0,0,0,.583.583h7.71a3.356,3.356,0,0,1-3.631,2.848H.583A.583.583,0,0,0,0,13.451v2.575a.583.583,0,0,0,.188.428l8.016,7.4a.583.583,0,0,0,.4.155h4.01A.583.583,0,0,0,13,23L5.676,16.232a6.653,6.653,0,0,0,6.718-6.212h2.565a.583.583,0,0,0,.583-.583V7.5a.583.583,0,0,0-.583-.583h-2.85a6.652,6.652,0,0,0-.692-1.554Z" transform="translate(0 -2.25)" fill="#fff" />
                        </svg>
                        0.01 </span>
                </p>
            </div> -->
        </div>
    </div>

</div>
</template>

<script>
export default {
    name: 'SettingHeading',
    props: {
        sub_heading: String
    }
}
</script>

<style scoped>

  </style>
