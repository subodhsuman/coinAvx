<template>
<div>
    <section class="banner_section d-flex align-items-center justify-content-center">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12 col-lg-12 col-xl-12 px-0">
                    <div class="banner_slider">
                        <div id="carouselExampleDark" class="carousel carousel-dark slide" data-bs-ride="carousel">
                            <div class="carousel-inner">
                                <div class="carousel-item active" data-bs-interval="10000">
                                    <div class="row  align-items-center justify-content-between">
                                        <div class="col-md-6 col-lg-6 col-xl-6">
                                            <div class="banner_content mb-3">
                                                <div class="heading_banner">
                                                    <h1 class="text-capitalize">Discover the next crypto <br> gem on <span> CoinAVX <img src="@/assets/images/landing-page/banner/star.png" alt="star" class="img-fluid"></span></h1>
                                                    <h3 class="text-capitalize mb-4">Put an end to losing your change on the couch!</h3>
                                                    <p>Buy, Sell, and Trade with Confidence on CoinAVX - Your one-stop <br> cryptocurrency exchange platform for your financial needs.<br>Trusted. Secure. Reliable. Fast!</p>
                                                </div>
                                                <div class="btn-banner  d-flex align-items-center mt-5 gap-5" aria-label="Basic example">
                                                    <div>
                                                        <button type="button" class="btn_explore text-capitalize shadow-none border-0">Explore now</button>
                                                    </div>
                                                    <div class="text-center px-3">
                                                        <button type="button" class="btn_create text-capitalize shadow-none border-0">create</button>
                                                    </div>
                                                </div>

                                            </div>
                                        </div>
                                        <!--__________ banner_info ___________-->
                                        <div class="col-md-6 col-lg-6 col-xl-6">
                                            <div class="banner_img text-end">
                                                <img src="@/assets/images/landing-page/banner/img1.png" alt="banner_img" class="img-fluid">
                                            </div>
                                        </div>
                                        <!--__________ banner_image ___________-->
                                    </div>

                                </div>
                                <!-- __________first banner _______________-->

                                <div class="carousel-item " data-bs-interval="2000">
                                    <div class="row  align-items-center justify-content-between">
                                        <div class="col-md-6 col-lg-6 col-xl-6">
                                            <div class="banner_content1 mb-3">
                                                <div class="heading_banner1">
                                                    <h1 class="text-capitalize">discover rare <br> collection of art <span> NFTs</span> </h1>
                                                    <p class="text-capitalize">digital marketplace for crypto collections and <br> non-fugiable tokens <span>NFTS</span> <img src="@/assets/images/landing-page/banner/star1.png" alt="star" class="img-fluid"></p>
                                                </div>
                                                <div class="btn-banner  d-flex align-items-center mt-5 gap-5" aria-label="Basic example">
                                                    <div>
                                                        <button type="button" class="btn_explore text-capitalize shadow-none border-0">Explore now</button>
                                                    </div>
                                                    <div class="text-center px-3">
                                                        <button type="button" class="btn_create text-capitalize shadow-none border-0">create</button>
                                                    </div>
                                                </div>
                                                <div class="banner_list">
                                                    <ul class="list-group  mt-5 list-group-horizontal">
                                                        <li class="list-group-item me-4 ps-0">
                                                            <h1>1223k <br><span>User</span></h1>
                                                        </li>
                                                        <li class="list-group-item  me-4">
                                                            <h1>156k <br><span>Artwork</span></h1>
                                                        </li>
                                                        <li class="list-group-item  me-4">
                                                            <h1>156k <br><span>Artist</span></h1>
                                                        </li>
                                                    </ul>
                                                </div>

                                            </div>
                                        </div>
                                        <!--__________ banner_info ___________-->
                                        <div class="col-md-6 col-lg-6 col-xl-6">
                                            <div class="banner_img text-center">
                                                <img src="@/assets/images/landing-page/banner/nft-img.png" alt="banner_img" class="img-fluid">
                                            </div>
                                        </div>
                                        <!--__________ banner_image ___________-->
                                    </div>

                                </div>
                                <!-- _________________second banner __________________ -->

                                <div class="carousel-item">
                                    <div class="row  align-items-center justify-content-between">
                                        <div class="col-md-6 col-lg-6 col-xl-6">
                                            <div class="banner_content2 mb-3">
                                                <div class="heading_banner">
                                                    <h1 class="text-capitalize"><span>trading comes </span> with <br>universal and timeless<br> principles</h1>
                                                    <p class="text-capitalize">In general, cryptocurrency trading bots help traders <br> to trade cryptocurrency based on predefined <br> conditions.</p>
                                                </div>
                                                <div class="btn-banner  d-flex align-items-center mt-5 gap-5" aria-label="Basic example">
                                                    <div>
                                                        <button type="button" class="btn_explore text-capitalize shadow-none border-0">Explore now</button>
                                                    </div>
                                                    <div class="text-center px-3">
                                                        <button type="button" class="btn_create text-capitalize shadow-none border-0">register</button>
                                                    </div>
                                                </div>

                                            </div>
                                        </div>
                                        <!--__________ banner_info ___________-->
                                        <div class="col-md-6 col-lg-6 col-xl-6">
                                            <div class="banner_img text-center">
                                                <img src="@/assets/images/landing-page/banner/nft-img.png" alt="banner_img" class="img-fluid">
                                            </div>
                                        </div>
                                        <!--__________ banner_image ___________-->
                                    </div>

                                </div>
                                <!-- _________________third banner __________________ -->

                                <div class="carousel-item">
                                    <div class="row  align-items-center justify-content-between height_img">
                                        <div class="col-md-6 col-lg-6 col-xl-6">
                                            <div class="banner_content3 mb-3">
                                                <div class="heading_banner">
                                                    <h1 class="text-capitalize"><span> GOLD </span> TRADING</h1>
                                                    <h3 class="text-capitalize mb-3">Get rid of the old and replace it with the new!</h3>
                                                    <p class="text-capitalize">Get what you want from Gold easily with your wallet money! <br>Effortless. Swift. Authentic!</p>
                                                </div>
                                                <div class="btn-banner1 mt-5" aria-label="Basic example">
                                                    <div>
                                                        <button type="button" class="btn_explore text-capitalize shadow-none border-0">Explore now</button>
                                                    </div>

                                                </div>

                                            </div>
                                        </div>
                                        <!--__________ banner_info ___________-->
                                        <div class="col-md-6 col-lg-6 col-xl-6">
                                            <div class="banner_img text-center">
                                                <img src="@/assets/images/landing-page/banner/forth-banner.png" alt="banner_img" class="img-fluid">
                                            </div>
                                        </div>
                                        <!--__________ banner_image ___________-->
                                    </div>

                                </div>
                                <!-- _________________forth banner __________________ -->
                            </div>
                            <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleDark" data-bs-slide="prev">
                                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                <span class="visually-hidden"></span>
                            </button>
                            <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleDark" data-bs-slide="next">
                                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                <span class="visually-hidden"></span>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--_________________ banner section component end __________________-->
</div>
</template>

<script>
export default {
    name: 'BannerComponent'
}
</script>

<style scoped>
.banner_section {
    position: relative;
    background-image: linear-gradient(91.99deg, rgb(2 2 8 / 81%) 9.44%, #111010 72.15%), url('@/assets/images/landing-page/banner/background.png');
    background-position: center;
    background-repeat: no-repeat;
    background-size: cover;
    min-height: 100vh;
}

.banner_section:after {
    position: absolute;
    bottom: 1px;
    left: 0;
    right: 0;
    content: '';
    background-image: url('@/assets/images/landing-page/banner/border-bottom.png');
    background-repeat: no-repeat;
    height: 29px;
    margin: 0 auto;
    width: 1366px;
}

.banner_content,
.banner_content1,
.banner_content2,
.banner_content3 {
    transform: translate(300px);
    position: relative;
}

.banner_content:before {
    position: absolute;
    top: -19px;
    left: -37px;
    content: '';
    height: 59px;
    width: 43px;
    background-image: url('@/assets/images/landing-page/banner/arrow_before.png');
    background-repeat: no-repeat;
}

.banner_content1:before {
    position: absolute;
    top: 154px;
    left: -12px;
    content: '';
    height: 76px;
    width: 3px;
    background-image: url('@/assets/images/landing-page/banner/line.png');
    background-repeat: no-repeat;
}

.banner_content2:before {
    position: absolute;
    top: 243px;
    left: -10px;
    content: '';
    height: 76px;
    width: 3px;
    background-image: url('@/assets/images/landing-page/banner/line.png');
    background-repeat: no-repeat;
}

.banner_content3:before {
    position: absolute;
    top: 130px;
    left: -10px;
    content: '';
    height: 76px;
    width: 3px;
    background-image: url('@/assets/images/landing-page/banner/line.png');
    background-repeat: no-repeat;
}

.banner_content3:after {
    position: absolute;
    top: -21px;
    left: -35px;
    content: '';
    height: 59px;
    width: 43px;
    background-image: url('@/assets/images/landing-page/banner/arrow_before1.png');
    background-repeat: no-repeat;
}

.heading_banner h1,
.heading_banner1 h1 {
    font-family: 'DEICHO';
    font-weight: 700;
    font-size: 53px;
    line-height: 145.02%;
    color: var(--landing-white);
}

.heading_banner h1 span,
.heading_banner1 h1 span {
    color: var(--avx-yellow);
}

.heading_banner h3 {
    font-weight: 600;
    font-size: 25px;
    line-height: 145.02%;
    color: var(--landing-white);
    font-family: 'Oxanium';
}

.heading_banner p,
.heading_banner1 p {
    font-family: 'Oxanium';
    font-weight: 400;
    font-size: 21px;
    line-height: 145.02%;
    letter-spacing: 0.03em;
    color: var(--avx-badge);
}

.btn_explore {
    font-size: 18px;
    color: var(--landing-black);
    padding: 5px 20px;
    background: unset;
    position: relative;
    font-family: 'Oxanium';
    font-weight: 700;
}

.btn-banner,
.btn-banner1 {
    position: relative;
}

.btn-banner::before {
    background-image: url('@/assets/images/landing-page/banner/border1_btn.png');
    background-repeat: no-repeat;
    position: absolute;
    top: -12px;
    left: -9px;
    content: '';
    margin: 0 auto;
    height: 58px;
    width: 189px;
}

.btn-banner1::before {
    background-image: url('@/assets/images/landing-page/banner/border1_btn.png');
    background-repeat: no-repeat;
    position: absolute;
    top: -12px;
    left: -9px;
    content: '';
    margin: 0 auto;
    height: 58px;
    width: 189px;
}

.btn-banner::after {
    background-image: url('@/assets/images/landing-page/banner/border_btn.png');
    background-repeat: no-repeat;
    position: absolute;
    top: -12px;
    left: 178px;
    content: '';
    margin: 0 auto;
    height: 58px;
    width: 189px;
}

.btn_create {
    font-size: 18px;
    color: var(--landing-white);
    padding: 5px 20px;
    background: unset;
    position: relative;
    cursor:pointer;
}

.heading_banner1 p span {
    color: var(--landing-white);
}

.list-group-item {
    background-color: unset;
    position: relative;
}

.list-group-item:before {
    position: absolute;
    top: 0;
    right: -14px;
    content: '';
    width: 2px;
    height: 60px;
    background-color: var(--avx-yellow);
    opacity: 0.44;
}

.list-group-item h1 {
    font-weight: 700;
    font-size: 23px;
    line-height: 26px;
    font-family: 'Oxanium';
    color: var(--landing-white);
}

.list-group-item h1 span {
    color: var(--avx-badge);
    font-weight: 500;
    font-size: 14px;
}
.height_img{
    height:850px;
}
/* slider button */
.carousel-control-prev-icon {
    background-image: url('@/assets/images/landing-page/banner/prev.png');
}

.carousel-control-next-icon {
    background-image: url('@/assets/images/landing-page/banner/next.png');
}

.carousel-dark .carousel-control-next-icon,
.carousel-dark .carousel-control-prev-icon {
    filter: unset;
}

.carousel-control-next,
.carousel-control-prev {
    top: unset;
    bottom: -121px;
    width: 98%;
}
@media (min-width:1200px) and (max-width:1399px) {
    section{
    padding: 40px 0;
   }
    .banner_content,
    .banner_content1,
    .banner_content2,
    .banner_content3 {
        transform: translate(58px);
        padding-top: 30px;
    }
    .heading_banner h1, .heading_banner1 h1{
        font-size: 36px;
    }
    .banner_section:after,
    .banner_content:before,
    .input-group{
        display: none;
    }
    .carousel-control-next, .carousel-control-prev{
        bottom:-97px;
    }
}
@media (min-width:992px) and (max-width:1199px) {
    section{
    padding: 40px 0;
   }
    .banner_content,
    .banner_content1,
    .banner_content2,
    .banner_content3 {
        transform: translate(58px);
        padding-top: 30px;
    }
    .heading_banner h1, .heading_banner1 h1{
        font-size: 36px;
    }
    .banner_section:after,
    .banner_content:before,
    .input-group{
        display: none;
    }
    .carousel-control-next, .carousel-control-prev{
        width:96%;
    }
    .whats_coinavx .main_heading:before, .feature_coinavx .main_heading:before {
    left: 261px;
}


}

@media (min-width:768px) and (max-width:991px) {
   section{
    padding: 40px 0;
   }
    .banner_content,
    .banner_content1,
    .banner_content2,
    .banner_content3 {
        transform: translate(38px);
        padding-top: 30px;
    }

    .banner_section:after,
    .banner_content:before,
    .input-group{
        display: none;
    }
    .carousel-control-next .carousel-control-prev{
        width:95%;
    }
    .banner_content2:before,
    .banner_content3:before,
    .banner_content1:before,
    .banner_content3:after {
        display: none;
    }
    .carousel-control-next, .carousel-control-prev{
        width:95%;
    }
    .heading_banner h1, .heading_banner1 h1{
        font-size:37px;
    }
    .heading_banner h1, .heading_banner1 h1{
        font-size:30px;
    }
    section{
    padding:40px 0;
 }
 .banner_section{
    min-height:70vh;
 }
 .heading_banner p, .heading_banner1 p{
    font-size:17px;
 }
 .carousel-control-next, .carousel-control-prev{
    bottom: -119px;
 }
 .height_img{
    height:460px;
 }
}

@media all and (min-width: 320px) and (max-width: 767px) {
 section{
    padding:40px 0;
 }
    .banner_content,
    .banner_content1,
    .banner_content2,
    .banner_content3 {
        transform: translate(13px);
        padding-top: 30px;
    }

    .banner_section:after,
    .banner_content:before,
    .input-group {
        display: none;
    }

    .heading_banner h1,
    .heading_banner1 h1 {
        font-size: 25px;
    }

    .carousel-control-next,
    .carousel-control-prev {
        width: 282px;
    }

    .heading_banner h3 {
        font-size: 21px;
    }

    .heading_banner p,
    .heading_banner1 p {
        font-size: 14px;
    }

    .heading_banner p br,
    .heading_banner1 p br {
        display: none;
    }

    .btn-banner {
        flex-direction: column;
        align-items: start !important;
    }

    .btn-banner::after {
        top: 77px;
        left: -2px;
    }

    .btn-banner::before {
        left: -2px;
    }

    .btn_explore {
        padding: 5px 20px 5px 25px;
    }

    .btn_create {
        padding: 5px 35px;
    }

    .banner_content2:before,
    .banner_content3:before,
    .banner_content1:before,
    .banner_content3:after {
        display: none;
    }

}
</style>
