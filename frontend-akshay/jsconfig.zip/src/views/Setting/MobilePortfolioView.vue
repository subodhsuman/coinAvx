<template>
<div class="mob-view">
    <SettingSideNavbar/>
</div>
</template>

<script>
import SettingSideNavbar from '../../components/setting/SettingSideNavbar.vue';
export default {
    name: 'MobilePortfolioView',
    components: {
    SettingSideNavbar
}
}
</script>
<style scoped>
.mob-view {
    /* background-color: var(--green); */
}
</style>

